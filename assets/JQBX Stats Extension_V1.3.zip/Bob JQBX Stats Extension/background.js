//background

function mycallback(info, tab) {
    chrome.tabs.sendMessage(tab.id, "getClickedEl", {frameId: info.frameId}, data => {
        elt.value = data.value;
    });
}



// chrome.browserAction.onClicked.addListener(function(tab) {
//     chrome.tabs.executeScript(null, {file: "content.js"});
// });


// chrome.contextMenus.create({
// 	title: "Copy These Tracks",
// 	contexts: ["page"],
// 	onclick: copyTracks
// });

// function copyTracks () {
// 	copyTracksToCLipBoard = require ('./content.js');
// 	copyTracksToCLipBoard();

// }





// var mySearchString;
// function activate_search(the_tab) {
// 	try {
// 		chrome.tabs.get(the_tab,
// 			function (tab_content) {
// 				chrome.tabs.onUpdated.removeListener(activate_search);

// 				chrome.tabs.executeScript(the_tab,
// 					{ code: "var mySearchString = '" + mySearchString + "';" },
// 					function (result) { });
// 				chrome.tabs.executeScript(the_tab,
// 					{ file: "do_search.js" },
// 					function (result) { });
// 			})
// 	}
// 	catch (damn_errors) { alert(damn_errors); alert(the_tab) };
// }
// function search_tt(e) {
// 	mySearchString = e.selectionText;
// 	chrome.tabs.query({ "url": "https://turntable.fm/*" },
// 		function (result) {
// 			if (result.length != 0) {
// 				chrome.tabs.highlight({ "tabs": [result[0].index] });
// 				result[0].active = true;
// 				activate_search(result[0].id);
// 			}
// 			else {
// 				chrome.tabs.onUpdated.addListener(activate_search);
// 				chrome.tabs.create({ url: "http://turntable.fm" });
// 			};
// 		});
// }

// function throwCurrentURL(e) {
// 	mySearchString = e.pageUrl;
	
// 	chrome.tabs.query({ "url": "https://turntable.fm/*" },
// 		function (result) {
// 			if (result.length != 0) {
// 				chrome.tabs.highlight({ "tabs": [result[0].index] });
// 				result[0].active = true;
// 				activate_search(result[0].id);
// 			}
// 			else {
// 				console.log(e);
// 				alert("sorry you don't have any Turntable DJ Room open in this Chrome !" + e);
// 			};
// 		});

// }
// chrome.contextMenus.create({
// 	title: "Search Turntable for \"%s\"",
// 	contexts: ["selection"],
// 	onclick: search_tt
// });
// chrome.contextMenus.create({
// 	title: "Throw into Turntable queue",
// 	contexts: ["page"],
// 	onclick: throwCurrentURL
// });
