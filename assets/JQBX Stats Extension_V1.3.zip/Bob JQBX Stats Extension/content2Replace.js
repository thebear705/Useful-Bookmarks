var clickedEl = null;
console.log("injected");



document.addEventListener('click', function(e) {
    e = e || window.event;
    clickedEl = e.target || e.srcElement,
	// CHOSEN_LIST = target.textContent || target.innerText;  
    console.log(clickedEl.textContent);

    copyTracksToCLipBoard();

}, false);




function copyTracksToCLipBoard() {
	if (clickedEl != null) {
        //  HomePage
        if (clickedEl.className == "w3-container w3-black") {
            tracks = clickedEl.parentElement.getElementsByClassName("w3-row");
            copyContents = "";
            for (track of tracks){
                songname = track.getElementsByClassName("w3-col")[0].textContent;
                dot = songname.indexOf(".");
                songname = songname.substr(dot+2,songname.length);
                
                a = copyContents.concat("\n" + songname);
                copyContents = a;
            }
            // window.prompt("copy this text",copyContents);
            navigator.clipboard.writeText(copyContents);  

            alert("Copied these songs from " + clickedEl.textContent +  " \n" + copyContents );
        }
        //  Stats Page
        else if (   clickedEl.className == "w3-row w3-blue" || 
                    clickedEl.className == "w3-row w3-green" ||
                    clickedEl.className == "w3-row w3-red" ||
                    clickedEl.className == "w3-row w3-light-green"  ) {

            tracks = clickedEl.nextElementSibling.getElementsByClassName("w3-col w3-left");
            copyContents = "";
            for (track of tracks){
                songname = track.textContent;
                if (songname.indexOf(" - ") == -1) {
                    continue;
                }
               
                
                a = copyContents.concat("\n" + songname);
                copyContents = a;
            }
            // window.prompt("copy this text",copyContents);
            navigator.clipboard.writeText(copyContents);  

            alert("Copied these songs from " + clickedEl.textContent +  " \n" + copyContents );
        }
        // clickedEl = null;
    }
    
}

if (clickedEl != null) {
    copyTracksToCLipBoard();
}
