function activate_search(){
	if(document.getElementsByClassName("room-container").length == 1) document.getElementsByClassName("tab-title")[0].parentElement.dispatchEvent(new Event("click"));//if the user is in a room we activate the Song Queue Tab first 
all_inputs = document.getElementsByTagName('input');
search_field = all_inputs[all_inputs.length-1];
search_field.value = mySearchString;
submit_event = new Event('submit');
search_field.dispatchEvent(new Event('keyup'));
search_field.parentElement.dispatchEvent(submit_event);}

setTimeout(activate_search,1000);