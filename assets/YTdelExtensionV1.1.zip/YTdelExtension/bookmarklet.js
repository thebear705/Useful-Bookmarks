function remove_played() {
    text = document.getElementsByClassName("index-message")[0].textContent
    n = text.indexOf("/");
    num_to_del = parseInt(text.substring(0, n)) - 1;
	
	playlist = document.getElementById("playlist");

    for (i = 0; i < num_to_del; i++) {
        setTimeout(function () {
            playlist.querySelectorAll('#button[aria-label="Action menu"]')[0].click()
			setTimeout(function () { document.getElementsByTagName("ytd-menu-service-item-renderer")[0].click()},500);
        }, 2000*i);
       
    }

}
var r = confirm("Do you want to delete all the videos that havce been already played?");
if (r == true) {
    remove_played();
} 




